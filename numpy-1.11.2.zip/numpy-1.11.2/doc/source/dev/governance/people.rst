.. _governance-people:

Current steering council and institutional partners
===================================================

Steering council
----------------

* Sebastian Berg

* Jaime Fernández del Río

* Ralf Gommers

* Alex Griffing

* Charles Harris

* Nathaniel Smith

* Julian Taylor

* Pauli Virtanen


Emeritus members
----------------

* Travis Oliphant - Project Founder / Emeritus Leader (served: 2005-2012)


NumFOCUS Subcommittee
---------------------

* Chuck Harris

* Ralf Gommers

* Jaime Fernández del Río

* Nathaniel Smith

* External member: Thomas Caswell


Institutional Partners
----------------------

*  UC Berkeley (Nathaniel Smith)


Document history
----------------

https://github.com/numpy/numpy/commits/master/doc/source/dev/governance/governance.rst
