scipy.odr.ODR.run
=================

.. currentmodule:: scipy.odr

.. automethod:: scipy.odr.ODR.run

